﻿

Option Strict On



Public Class frmDisplaySalary
    Public Property StringPass As String

    Private Sub frmDisplaySalary_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        lblShow.Text = StringPass
        'Dim strJobTitle As String

        'Array.Sort(frmITJobs._strInventoryItem)

        'For Each strJobTitle In frmITJobs._strInventoryItem
        '    lstDisplay.Items.Add(strJobTitle)
        'Next

    End Sub

    Private Sub lblSalary_Click(sender As Object, e As EventArgs) Handles lblSalary.Click
        'Dim frmFirst As New frmITJobs

        'Hide()
        'frmFirst.ShowDialog()

    End Sub

    Private Sub lblShow_Click(sender As Object, e As EventArgs) Handles lblShow.Click

    End Sub

    Private Sub btnReturn_Click(sender As Object, e As EventArgs) Handles btnReturn.Click

        Dim frmFirst As New frmITJobs

        Hide()
        frmFirst.ShowDialog()
    End Sub
End Class