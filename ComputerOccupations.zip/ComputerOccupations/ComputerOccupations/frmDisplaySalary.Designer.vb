﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDisplaySalary
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmDisplaySalary))
        Me.lblSalary = New System.Windows.Forms.Label()
        Me.picCosmic = New System.Windows.Forms.PictureBox()
        Me.btnReturn = New System.Windows.Forms.Button()
        Me.lstDisplay = New System.Windows.Forms.ListBox()
        Me.lblShow = New System.Windows.Forms.Label()
        CType(Me.picCosmic, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblSalary
        '
        Me.lblSalary.AutoSize = True
        Me.lblSalary.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSalary.Location = New System.Drawing.Point(29, 87)
        Me.lblSalary.Name = "lblSalary"
        Me.lblSalary.Size = New System.Drawing.Size(312, 25)
        Me.lblSalary.TabIndex = 0
        Me.lblSalary.Text = "Salary for IT Jobs 2015 to 2020" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'picCosmic
        '
        Me.picCosmic.Image = CType(resources.GetObject("picCosmic.Image"), System.Drawing.Image)
        Me.picCosmic.Location = New System.Drawing.Point(-1, 3)
        Me.picCosmic.Name = "picCosmic"
        Me.picCosmic.Size = New System.Drawing.Size(108, 68)
        Me.picCosmic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picCosmic.TabIndex = 1
        Me.picCosmic.TabStop = False
        '
        'btnReturn
        '
        Me.btnReturn.BackColor = System.Drawing.Color.Black
        Me.btnReturn.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReturn.ForeColor = System.Drawing.Color.Red
        Me.btnReturn.Location = New System.Drawing.Point(90, 300)
        Me.btnReturn.Name = "btnReturn"
        Me.btnReturn.Size = New System.Drawing.Size(178, 36)
        Me.btnReturn.TabIndex = 2
        Me.btnReturn.Text = "Return to Application"
        Me.btnReturn.UseVisualStyleBackColor = False
        '
        'lstDisplay
        '
        Me.lstDisplay.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstDisplay.FormattingEnabled = True
        Me.lstDisplay.ItemHeight = 20
        Me.lstDisplay.Items.AddRange(New Object() {"Computer Developers", "857,000", "1,181,000", "", "Computer Support", "862,000", "1,016,000", "", "Systems Analysts", "504,000", "650,000", "", "Database Administrators", "119,000", "154,000", "", "Network Administrators", "262,000", "402,000", "", "IT Managers ", "205,000", "307,000"})
        Me.lstDisplay.Location = New System.Drawing.Point(107, 144)
        Me.lstDisplay.Name = "lstDisplay"
        Me.lstDisplay.Size = New System.Drawing.Size(143, 84)
        Me.lstDisplay.TabIndex = 3
        '
        'lblShow
        '
        Me.lblShow.AutoSize = True
        Me.lblShow.Location = New System.Drawing.Point(153, 248)
        Me.lblShow.Name = "lblShow"
        Me.lblShow.Size = New System.Drawing.Size(34, 13)
        Me.lblShow.TabIndex = 4
        Me.lblShow.Text = "Show"
        '
        'frmDisplaySalary
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(371, 380)
        Me.Controls.Add(Me.lblShow)
        Me.Controls.Add(Me.lstDisplay)
        Me.Controls.Add(Me.btnReturn)
        Me.Controls.Add(Me.picCosmic)
        Me.Controls.Add(Me.lblSalary)
        Me.Name = "frmDisplaySalary"
        Me.Text = "Salary Listing"
        CType(Me.picCosmic, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblSalary As Label
    Friend WithEvents picCosmic As PictureBox
    Friend WithEvents btnReturn As Button
    Friend WithEvents lstDisplay As ListBox
    Friend WithEvents lblShow As Label
End Class
