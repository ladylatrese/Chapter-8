﻿
Option Strict On 
Public Class frmITJobs
    Private _intLifeofItems As Integer = 5
    Public Shared _intSizeOfArray As Integer = 7
    Public Shared _strInventoryItem(_intSizeOfArray) As String
    Private _strItemId(_intSizeOfArray) As String
    Private _decInitalPrice(_intSizeOfArray) As Decimal
    Dim JobTitle As String
    Dim totalJobs As String
    Public Property Response As Object

    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click


        If (JobTitle = "1") Then

            totalJobs = "Job Title - Computer Developers. Jobs in 2015 - 857,000. Jobs Projected for 2020 - 1,181,000"

        ElseIf (JobTitle = "2") Then

            totalJobs = "Job Title - Computer Support. Jobs in 2015 - 862,000. Jobs Projected for 2020 - 1,016,000"

        ElseIf (JobTitle = "3") Then

            totalJobs = "Job Title - Systems Analysts. Jobs in 2015 - 504,000. Jobs Projected for 2020 - 650,000"

        ElseIf (JobTitle = "4") Then

            totalJobs = "Job Title - Database Administrators. Jobs in 2015 - 119,000. Jobs Projected for 2020 - 154,000"

        ElseIf (JobTitle = "5") Then

            totalJobs = "Job Title - Network Administrators. Jobs in 2015 - 262,000. Jobs Projected for 2020 - 402,000"

        ElseIf (JobTitle = "6") Then

            totalJobs = "Job Title - IT Managers. Jobs in 2015 - 205,000. Jobs Projected for 2020 - 307,000"

        End If
        Dim obj As New frmDisplaySalary
        obj.StringPass = totalJobs
        obj.Show()

    End Sub

    Private Sub frmITJobs_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub lblTitle_Click(sender As Object, e As EventArgs) Handles lblTitle.Click

    End Sub
End Class