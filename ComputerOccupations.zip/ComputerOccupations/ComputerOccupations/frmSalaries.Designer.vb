﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSalaries
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmSalaries))
        Me.frmPanel = New System.Windows.Forms.Panel()
        Me.lblLength = New System.Windows.Forms.Label()
        Me.lblCost = New System.Windows.Forms.Label()
        Me.lblJobType = New System.Windows.Forms.Label()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnFindJob = New System.Windows.Forms.Button()
        Me.lstSalary = New System.Windows.Forms.ListBox()
        Me.lblSelect = New System.Windows.Forms.Label()
        Me.txtJob = New System.Windows.Forms.TextBox()
        Me.lblJob = New System.Windows.Forms.Label()
        Me.cboJob = New System.Windows.Forms.ComboBox()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.frmPanel.SuspendLayout()
        Me.SuspendLayout()
        '
        'frmPanel
        '
        Me.frmPanel.BackColor = System.Drawing.Color.Transparent
        Me.frmPanel.Controls.Add(Me.lblLength)
        Me.frmPanel.Controls.Add(Me.lblCost)
        Me.frmPanel.Controls.Add(Me.lblJobType)
        Me.frmPanel.Controls.Add(Me.btnClear)
        Me.frmPanel.Controls.Add(Me.btnFindJob)
        Me.frmPanel.Controls.Add(Me.lstSalary)
        Me.frmPanel.Controls.Add(Me.lblSelect)
        Me.frmPanel.Controls.Add(Me.txtJob)
        Me.frmPanel.Controls.Add(Me.lblJob)
        Me.frmPanel.Controls.Add(Me.cboJob)
        Me.frmPanel.Controls.Add(Me.lblTitle)
        Me.frmPanel.Location = New System.Drawing.Point(402, 2)
        Me.frmPanel.Name = "frmPanel"
        Me.frmPanel.Size = New System.Drawing.Size(455, 453)
        Me.frmPanel.TabIndex = 0
        '
        'lblLength
        '
        Me.lblLength.AutoSize = True
        Me.lblLength.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLength.Location = New System.Drawing.Point(79, 423)
        Me.lblLength.Name = "lblLength"
        Me.lblLength.Size = New System.Drawing.Size(180, 25)
        Me.lblLength.TabIndex = 10
        Me.lblLength.Text = "XXXXXXXXXXXX" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.lblLength.Visible = False
        '
        'lblCost
        '
        Me.lblCost.AutoSize = True
        Me.lblCost.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCost.Location = New System.Drawing.Point(79, 398)
        Me.lblCost.Name = "lblCost"
        Me.lblCost.Size = New System.Drawing.Size(180, 25)
        Me.lblCost.TabIndex = 9
        Me.lblCost.Text = "XXXXXXXXXXXX" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.lblCost.Visible = False
        '
        'lblJobType
        '
        Me.lblJobType.AutoSize = True
        Me.lblJobType.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblJobType.Location = New System.Drawing.Point(95, 373)
        Me.lblJobType.Name = "lblJobType"
        Me.lblJobType.Size = New System.Drawing.Size(180, 25)
        Me.lblJobType.TabIndex = 8
        Me.lblJobType.Text = "XXXXXXXXXXXX" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.lblJobType.Visible = False
        '
        'btnClear
        '
        Me.btnClear.BackColor = System.Drawing.Color.Sienna
        Me.btnClear.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnClear.ForeColor = System.Drawing.Color.Khaki
        Me.btnClear.Location = New System.Drawing.Point(265, 347)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(102, 23)
        Me.btnClear.TabIndex = 7
        Me.btnClear.Text = "Clear Form"
        Me.btnClear.UseVisualStyleBackColor = False
        Me.btnClear.Visible = False
        '
        'btnFindJob
        '
        Me.btnFindJob.BackColor = System.Drawing.Color.Sienna
        Me.btnFindJob.ForeColor = System.Drawing.Color.Khaki
        Me.btnFindJob.Location = New System.Drawing.Point(41, 347)
        Me.btnFindJob.Name = "btnFindJob"
        Me.btnFindJob.Size = New System.Drawing.Size(95, 23)
        Me.btnFindJob.TabIndex = 6
        Me.btnFindJob.Text = "Find Job Salary"
        Me.btnFindJob.UseVisualStyleBackColor = False
        Me.btnFindJob.Visible = False
        '
        'lstSalary
        '
        Me.lstSalary.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstSalary.FormattingEnabled = True
        Me.lstSalary.ItemHeight = 24
        Me.lstSalary.Location = New System.Drawing.Point(135, 220)
        Me.lstSalary.Name = "lstSalary"
        Me.lstSalary.Size = New System.Drawing.Size(120, 76)
        Me.lstSalary.TabIndex = 5
        Me.lstSalary.Visible = False
        '
        'lblSelect
        '
        Me.lblSelect.AutoSize = True
        Me.lblSelect.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSelect.Location = New System.Drawing.Point(132, 184)
        Me.lblSelect.Name = "lblSelect"
        Me.lblSelect.Size = New System.Drawing.Size(123, 24)
        Me.lblSelect.TabIndex = 4
        Me.lblSelect.Text = "Select Salary "
        Me.lblSelect.Visible = False
        '
        'txtJob
        '
        Me.txtJob.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtJob.Location = New System.Drawing.Point(280, 142)
        Me.txtJob.Name = "txtJob"
        Me.txtJob.Size = New System.Drawing.Size(33, 31)
        Me.txtJob.TabIndex = 3
        Me.txtJob.Visible = False
        '
        'lblJob
        '
        Me.lblJob.AutoSize = True
        Me.lblJob.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblJob.Location = New System.Drawing.Point(72, 137)
        Me.lblJob.Name = "lblJob"
        Me.lblJob.Size = New System.Drawing.Size(163, 25)
        Me.lblJob.TabIndex = 2
        Me.lblJob.Text = "Number of Jobs"
        Me.lblJob.Visible = False
        '
        'cboJob
        '
        Me.cboJob.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboJob.FormattingEnabled = True
        Me.cboJob.Items.AddRange(New Object() {"Computer Developers", "Computer System Analysts", "Computer and Information Systems Managers", "Computer Software Engineers "})
        Me.cboJob.Location = New System.Drawing.Point(116, 82)
        Me.cboJob.Name = "cboJob"
        Me.cboJob.Size = New System.Drawing.Size(187, 32)
        Me.cboJob.TabIndex = 1
        Me.cboJob.Text = "Select Occupation"
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Verdana", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.Location = New System.Drawing.Point(8, 31)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(359, 32)
        Me.lblTitle.TabIndex = 0
        Me.lblTitle.Text = "Computer Occupations"
        '
        'frmSalaries
        '
        Me.AcceptButton = Me.btnFindJob
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.CancelButton = Me.btnClear
        Me.ClientSize = New System.Drawing.Size(884, 533)
        Me.Controls.Add(Me.frmPanel)
        Me.Name = "frmSalaries"
        Me.Text = "Computer Occupations"
        Me.frmPanel.ResumeLayout(False)
        Me.frmPanel.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents frmPanel As Panel
    Friend WithEvents cboJob As ComboBox
    Friend WithEvents lblTitle As Label
    Friend WithEvents lblCost As Label
    Friend WithEvents lblJobType As Label
    Friend WithEvents btnClear As Button
    Friend WithEvents btnFindJob As Button
    Friend WithEvents lstSalary As ListBox
    Friend WithEvents lblSelect As Label
    Friend WithEvents txtJob As TextBox
    Friend WithEvents lblJob As Label
    Friend WithEvents lblLength As Label
End Class
