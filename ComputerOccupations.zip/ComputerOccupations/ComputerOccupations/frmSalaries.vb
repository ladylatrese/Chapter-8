﻿'Program Name:  Computer Occupations
'Author:  Candice Lipsey
'Date: March 31,2019
'Purpose:  Create a Windows application that analyzes four computer job titles from the information listed on the US Department from
' website at www.bls.gov.
Option Strict On

Public Class frmSalaries
    'Class variables 
    Private _intOneHour As Integer = 1
    Private _intTwoHour As Integer = 2
    Private _intFourHour As Integer = 4
    Private _strJob1 As String = "$103,560 per year $49.79 per hour"
    Private _strJob2 As String = "$88,270 per year $42.44 per hour"
    Private _strJob3 As String = "$139,220 per year $66.93 per hour"
    Private _strJob4 As String = "$115,120 per year $55.35 per hour"



    Private Sub cboJob_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboJob.SelectedIndexChanged
        'This event handler allows the user to enter job choice and then calls subprocedures to place the salary type in the list
        Dim intJobChoice As Integer
        intJobChoice = cboJob.SelectedIndex
        lstSalary.Items.Clear()
        Select Case intJobChoice
            Case 0
                lblSelect.Text = "$103,560 per year $49.79 per hour"
            Case 1
                lblSelect.Text = "$88,270 per year $42.44 per hour"
            Case Else
                lblSelect.Text = "$139,220 per year $66.93 per hour"
        End Select
        'Make items visible in the window
        lblJob.Visible = True
        txtJob.Visible = True
        lblSelect.Visible = True
        lstSalary.Visible = True
        btnFindJob.Visible = True
        btnClear.Visible = True
        lblJobType.Visible = True
        lblCost.Visible = True
        lblLength.Visible = True
        'Clear the labels
        lblJobType.Text = ""
        lblCost.Text = ""
        lblLength.Text = ""
        'Set focus on number in job text box
        txtJob.Focus()
    End Sub
    Private Sub Computer()
        lstSalary.Items.Add(_strJob1)





    End Sub

    Private ReadOnly Property Analysts As Object
        Get
            Throw New NotImplementedException()
        End Get
    End Property

    Private Sub ComputerDevelopers()
        Throw New NotImplementedException()
    End Sub

    Private Sub lblCost_Click(sender As Object, e As EventArgs) Handles lblCost.Click

    End Sub

    Private Sub lblSelect_Click(sender As Object, e As EventArgs) Handles lblSelect.Click

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        cboJob.Text = "Select Occupation"
        txtJob.Clear()
        lstSalary.Items.Clear()
        lblJobType.Text = ""
        lblCost.Text = ""
        lblLength.Text = ""
        lblJob.Visible = False
        txtJob.Visible = False
        lblSelect.Visible = False
        lstSalary.Visible = False
        btnFindJob.Visible = False
        btnClear.Visible = False
        lblJobType.Visible = False
        lblCost.Visible = False
        lblLength.Visible = False
    End Sub

    Private Sub lblTitle_Click(sender As Object, e As EventArgs) Handles lblTitle.Click

    End Sub
End Class
