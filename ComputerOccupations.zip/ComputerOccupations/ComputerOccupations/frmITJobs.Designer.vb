﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmITJobs
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmITJobs))
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.lstJob = New System.Windows.Forms.ListBox()
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.picCosmic = New System.Windows.Forms.PictureBox()
        CType(Me.picCosmic, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Verdana", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.Location = New System.Drawing.Point(282, 48)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(390, 32)
        Me.lblTitle.TabIndex = 1
        Me.lblTitle.Text = "Information Technology " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'lstJob
        '
        Me.lstJob.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstJob.FormattingEnabled = True
        Me.lstJob.ItemHeight = 20
        Me.lstJob.Items.AddRange(New Object() {"Computer Developers", "Computer Support", "Systems Analysts", "Database Administrators", "Network Administrators", "IT Managers"})
        Me.lstJob.Location = New System.Drawing.Point(380, 99)
        Me.lstJob.Name = "lstJob"
        Me.lstJob.Size = New System.Drawing.Size(146, 104)
        Me.lstJob.TabIndex = 2
        '
        'btnSubmit
        '
        Me.btnSubmit.BackColor = System.Drawing.Color.Black
        Me.btnSubmit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSubmit.ForeColor = System.Drawing.Color.Red
        Me.btnSubmit.Location = New System.Drawing.Point(266, 329)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(115, 29)
        Me.btnSubmit.TabIndex = 3
        Me.btnSubmit.Text = "Submit"
        Me.btnSubmit.UseVisualStyleBackColor = False
        '
        'picCosmic
        '
        Me.picCosmic.Image = CType(resources.GetObject("picCosmic.Image"), System.Drawing.Image)
        Me.picCosmic.Location = New System.Drawing.Point(12, 12)
        Me.picCosmic.Name = "picCosmic"
        Me.picCosmic.Size = New System.Drawing.Size(243, 141)
        Me.picCosmic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picCosmic.TabIndex = 4
        Me.picCosmic.TabStop = False
        '
        'frmITJobs
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(884, 533)
        Me.Controls.Add(Me.picCosmic)
        Me.Controls.Add(Me.btnSubmit)
        Me.Controls.Add(Me.lstJob)
        Me.Controls.Add(Me.lblTitle)
        Me.Name = "frmITJobs"
        Me.Text = "frmITJobs"
        CType(Me.picCosmic, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblTitle As Label
    Friend WithEvents lstJob As ListBox
    Friend WithEvents btnSubmit As Button
    Friend WithEvents picCosmic As PictureBox
End Class
